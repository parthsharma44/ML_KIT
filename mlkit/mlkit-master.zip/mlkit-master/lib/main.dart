import 'package:flutter/material.dart';
import 'package:mlkit/ui/home.dart';

void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: "mlKit",
    home: Home(),
  ));
}